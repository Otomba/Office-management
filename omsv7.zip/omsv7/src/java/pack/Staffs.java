/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "staffs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Staffs.findAll", query = "SELECT s FROM Staffs s")
    , @NamedQuery(name = "Staffs.findById", query = "SELECT s FROM Staffs s WHERE s.id = :id")
    , @NamedQuery(name = "Staffs.findByDepartment", query = "SELECT s FROM Staffs s WHERE s.department = :department")
    , @NamedQuery(name = "Staffs.findByEmail", query = "SELECT s FROM Staffs s WHERE s.email = :email")
    , @NamedQuery(name = "Staffs.findByFirstname", query = "SELECT s FROM Staffs s WHERE s.firstname = :firstname")
    , @NamedQuery(name = "Staffs.findByLastname", query = "SELECT s FROM Staffs s WHERE s.lastname = :lastname")
    , @NamedQuery(name = "Staffs.findByLevel", query = "SELECT s FROM Staffs s WHERE s.level = :level")
    , @NamedQuery(name = "Staffs.findByLinemanager", query = "SELECT s FROM Staffs s WHERE s.linemanager = :linemanager")
    , @NamedQuery(name = "Staffs.findByPassword", query = "SELECT s FROM Staffs s WHERE s.password = :password")
    , @NamedQuery(name = "Staffs.findByPhonenumber", query = "SELECT s FROM Staffs s WHERE s.phonenumber = :phonenumber")
    , @NamedQuery(name = "Staffs.findByTitle", query = "SELECT s FROM Staffs s WHERE s.title = :title")
    , @NamedQuery(name = "Staffs.findByUsername", query = "SELECT s FROM Staffs s WHERE s.username = :username")})
public class Staffs implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "DEPARTMENT")
    private BigInteger department;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 100)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 100)
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Size(max = 100)
    @Column(name = "LASTNAME")
    private String lastname;
    @Column(name = "LEVEL")
    private BigInteger level;
    @Column(name = "LINEMANAGER")
    private BigInteger linemanager;
    @Size(max = 100)
    @Column(name = "PASSWORD")
    private String password;
    @Column(name = "PHONENUMBER")
    private BigInteger phonenumber;
    @Column(name = "TITLE")
    private BigInteger title;
    @Size(max = 100)
    @Column(name = "USERNAME")
    private String username;
    @OneToMany(mappedBy = "staffsId")
    private Collection<Comments> commentsCollection;
    @OneToMany(mappedBy = "staffsId")
    private Collection<Logs> logsCollection;
    @JoinColumn(name = "DEPARTMENTS_ID", referencedColumnName = "ID")
    @ManyToOne
    private Departments departmentsId;
    @JoinColumn(name = "LEVELS_ID", referencedColumnName = "ID")
    @ManyToOne
    private Levels levelsId;
    @OneToMany(mappedBy = "linemanagerId")
    private Collection<Staffs> staffsCollection;
    @JoinColumn(name = "LINEMANAGER_ID", referencedColumnName = "ID")
    @ManyToOne
    private Staffs linemanagerId;
    @JoinColumn(name = "TITLES_ID", referencedColumnName = "ID")
    @ManyToOne
    private Titles titlesId;

    public Staffs() {
    }

    public Staffs(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigInteger getDepartment() {
        return department;
    }

    public void setDepartment(BigInteger department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public BigInteger getLevel() {
        return level;
    }

    public void setLevel(BigInteger level) {
        this.level = level;
    }

    public BigInteger getLinemanager() {
        return linemanager;
    }

    public void setLinemanager(BigInteger linemanager) {
        this.linemanager = linemanager;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public BigInteger getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(BigInteger phonenumber) {
        this.phonenumber = phonenumber;
    }

    public BigInteger getTitle() {
        return title;
    }

    public void setTitle(BigInteger title) {
        this.title = title;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @XmlTransient
    public Collection<Comments> getCommentsCollection() {
        return commentsCollection;
    }

    public void setCommentsCollection(Collection<Comments> commentsCollection) {
        this.commentsCollection = commentsCollection;
    }

    @XmlTransient
    public Collection<Logs> getLogsCollection() {
        return logsCollection;
    }

    public void setLogsCollection(Collection<Logs> logsCollection) {
        this.logsCollection = logsCollection;
    }

    public Departments getDepartmentsId() {
        return departmentsId;
    }

    public void setDepartmentsId(Departments departmentsId) {
        this.departmentsId = departmentsId;
    }

    public Levels getLevelsId() {
        return levelsId;
    }

    public void setLevelsId(Levels levelsId) {
        this.levelsId = levelsId;
    }

    @XmlTransient
    public Collection<Staffs> getStaffsCollection() {
        return staffsCollection;
    }

    public void setStaffsCollection(Collection<Staffs> staffsCollection) {
        this.staffsCollection = staffsCollection;
    }

    public Staffs getLinemanagerId() {
        return linemanagerId;
    }

    public void setLinemanagerId(Staffs linemanagerId) {
        this.linemanagerId = linemanagerId;
    }

    public Titles getTitlesId() {
        return titlesId;
    }

    public void setTitlesId(Titles titlesId) {
        this.titlesId = titlesId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Staffs)) {
            return false;
        }
        Staffs other = (Staffs) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pack.Staffs[ id=" + id + " ]";
    }
    
}
