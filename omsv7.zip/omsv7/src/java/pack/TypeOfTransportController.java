/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class TypeOfTransportController {

    public TypeOfTransportController() {
        pagingInfo = new PagingInfo();
        converter = new TypeOfTransportConverter();
    }
    private TypeOfTransport typeOfTransport = null;
    private List<TypeOfTransport> typeOfTransportItems = null;
    private TypeOfTransportFacade jpaController = null;
    private TypeOfTransportConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public TypeOfTransportFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (TypeOfTransportFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "typeOfTransportJpa");
        }
        return jpaController;
    }

    public SelectItem[] getTypeOfTransportItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getTypeOfTransportItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public TypeOfTransport getTypeOfTransport() {
        if (typeOfTransport == null) {
            typeOfTransport = (TypeOfTransport) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTypeOfTransport", converter, null);
        }
        if (typeOfTransport == null) {
            typeOfTransport = new TypeOfTransport();
        }
        return typeOfTransport;
    }

    public String listSetup() {
        reset(true);
        return "typeOfTransport_list";
    }

    public String createSetup() {
        reset(false);
        typeOfTransport = new TypeOfTransport();
        return "typeOfTransport_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(typeOfTransport);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("TypeOfTransport was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("typeOfTransport_detail");
    }

    public String editSetup() {
        return scalarSetup("typeOfTransport_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        typeOfTransport = (TypeOfTransport) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTypeOfTransport", converter, null);
        if (typeOfTransport == null) {
            String requestTypeOfTransportString = JsfUtil.getRequestParameter("jsfcrud.currentTypeOfTransport");
            JsfUtil.addErrorMessage("The typeOfTransport with id " + requestTypeOfTransportString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String typeOfTransportString = converter.getAsString(FacesContext.getCurrentInstance(), null, typeOfTransport);
        String currentTypeOfTransportString = JsfUtil.getRequestParameter("jsfcrud.currentTypeOfTransport");
        if (typeOfTransportString == null || typeOfTransportString.length() == 0 || !typeOfTransportString.equals(currentTypeOfTransportString)) {
            String outcome = editSetup();
            if ("typeOfTransport_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit typeOfTransport. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(typeOfTransport);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("TypeOfTransport was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentTypeOfTransport");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("TypeOfTransport was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
     
        return listSetup();
    }

    public List<TypeOfTransport> getTypeOfTransportItems() {
        if (typeOfTransportItems == null) {
            getPagingInfo();
            typeOfTransportItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return typeOfTransportItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "typeOfTransport_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "typeOfTransport_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        typeOfTransport = null;
        typeOfTransportItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        TypeOfTransport newTypeOfTransport = new TypeOfTransport();
        String newTypeOfTransportString = converter.getAsString(FacesContext.getCurrentInstance(), null, newTypeOfTransport);
        String typeOfTransportString = converter.getAsString(FacesContext.getCurrentInstance(), null, typeOfTransport);
        if (!newTypeOfTransportString.equals(typeOfTransportString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
