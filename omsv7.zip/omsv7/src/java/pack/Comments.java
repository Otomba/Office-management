/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "comments")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Comments.findAll", query = "SELECT c FROM Comments c")
    , @NamedQuery(name = "Comments.findById", query = "SELECT c FROM Comments c WHERE c.id = :id")
    , @NamedQuery(name = "Comments.findByComment", query = "SELECT c FROM Comments c WHERE c.comment = :comment")
    , @NamedQuery(name = "Comments.findByOwnerofcomment", query = "SELECT c FROM Comments c WHERE c.ownerofcomment = :ownerofcomment")
    , @NamedQuery(name = "Comments.findByTypeOfComment", query = "SELECT c FROM Comments c WHERE c.typeOfComment = :typeOfComment")})
public class Comments implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 100)
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "OWNEROFCOMMENT")
    private BigInteger ownerofcomment;
    @Size(max = 100)
    @Column(name = "TYPE_OF_COMMENT")
    private String typeOfComment;
    @JoinColumn(name = "STAFFS_ID", referencedColumnName = "ID")
    @ManyToOne
    private Staffs staffsId;

    public Comments() {
    }

    public Comments(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public BigInteger getOwnerofcomment() {
        return ownerofcomment;
    }

    public void setOwnerofcomment(BigInteger ownerofcomment) {
        this.ownerofcomment = ownerofcomment;
    }

    public String getTypeOfComment() {
        return typeOfComment;
    }

    public void setTypeOfComment(String typeOfComment) {
        this.typeOfComment = typeOfComment;
    }

    public Staffs getStaffsId() {
        return staffsId;
    }

    public void setStaffsId(Staffs staffsId) {
        this.staffsId = staffsId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Comments)) {
            return false;
        }
        Comments other = (Comments) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pack.Comments[ id=" + id + " ]";
    }
    
}
