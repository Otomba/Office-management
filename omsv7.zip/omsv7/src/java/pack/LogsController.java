/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class LogsController {

    public LogsController() {
        pagingInfo = new PagingInfo();
        converter = new LogsConverter();
    }
    private Logs logs = null;
    private List<Logs> logsItems = null;
    private LogsFacade jpaController = null;
    private LogsConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public LogsFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (LogsFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "logsJpa");
        }
        return jpaController;
    }

    public SelectItem[] getLogsItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getLogsItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Logs getLogs() {
        if (logs == null) {
            logs = (Logs) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentLogs", converter, null);
        }
        if (logs == null) {
            logs = new Logs();
        }
        return logs;
    }

    public String listSetup() {
        reset(true);
        return "logs_list";
    }

    public String createSetup() {
        reset(false);
        logs = new Logs();
        return "logs_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(logs);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Logs was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("logs_detail");
    }

    public String editSetup() {
        return scalarSetup("logs_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        logs = (Logs) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentLogs", converter, null);
        if (logs == null) {
            String requestLogsString = JsfUtil.getRequestParameter("jsfcrud.currentLogs");
            JsfUtil.addErrorMessage("The logs with id " + requestLogsString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String logsString = converter.getAsString(FacesContext.getCurrentInstance(), null, logs);
        String currentLogsString = JsfUtil.getRequestParameter("jsfcrud.currentLogs");
        if (logsString == null || logsString.length() == 0 || !logsString.equals(currentLogsString)) {
            String outcome = editSetup();
            if ("logs_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit logs. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(logs);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Logs was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentLogs");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Logs was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
     
        return listSetup();
    }

    public List<Logs> getLogsItems() {
        if (logsItems == null) {
            getPagingInfo();
            logsItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return logsItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "logs_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "logs_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        logs = null;
        logsItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Logs newLogs = new Logs();
        String newLogsString = converter.getAsString(FacesContext.getCurrentInstance(), null, newLogs);
        String logsString = converter.getAsString(FacesContext.getCurrentInstance(), null, logs);
        if (!newLogsString.equals(logsString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
