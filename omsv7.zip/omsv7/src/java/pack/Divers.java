/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "divers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Divers.findAll", query = "SELECT d FROM Divers d")
    , @NamedQuery(name = "Divers.findById", query = "SELECT d FROM Divers d WHERE d.id = :id")
    , @NamedQuery(name = "Divers.findByCompany", query = "SELECT d FROM Divers d WHERE d.company = :company")
    , @NamedQuery(name = "Divers.findByEmail", query = "SELECT d FROM Divers d WHERE d.email = :email")
    , @NamedQuery(name = "Divers.findByFirstname", query = "SELECT d FROM Divers d WHERE d.firstname = :firstname")
    , @NamedQuery(name = "Divers.findByLastname", query = "SELECT d FROM Divers d WHERE d.lastname = :lastname")
    , @NamedQuery(name = "Divers.findByPhonenumber", query = "SELECT d FROM Divers d WHERE d.phonenumber = :phonenumber")})
public class Divers implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 100)
    @Column(name = "COMPANY")
    private String company;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 100)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 100)
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Size(max = 100)
    @Column(name = "LASTNAME")
    private String lastname;
    @Column(name = "PHONENUMBER")
    private BigInteger phonenumber;
    @OneToMany(mappedBy = "diversId")
    private Collection<Milleage> milleageCollection;
    @OneToMany(mappedBy = "diversId")
    private Collection<Costsettings> costsettingsCollection;
    @OneToMany(mappedBy = "diversId")
    private Collection<DriverAssign> driverAssignCollection;

    public Divers() {
    }

    public Divers(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public BigInteger getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(BigInteger phonenumber) {
        this.phonenumber = phonenumber;
    }

    @XmlTransient
    public Collection<Milleage> getMilleageCollection() {
        return milleageCollection;
    }

    public void setMilleageCollection(Collection<Milleage> milleageCollection) {
        this.milleageCollection = milleageCollection;
    }

    @XmlTransient
    public Collection<Costsettings> getCostsettingsCollection() {
        return costsettingsCollection;
    }

    public void setCostsettingsCollection(Collection<Costsettings> costsettingsCollection) {
        this.costsettingsCollection = costsettingsCollection;
    }

    @XmlTransient
    public Collection<DriverAssign> getDriverAssignCollection() {
        return driverAssignCollection;
    }

    public void setDriverAssignCollection(Collection<DriverAssign> driverAssignCollection) {
        this.driverAssignCollection = driverAssignCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Divers)) {
            return false;
        }
        Divers other = (Divers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pack.Divers[ id=" + id + " ]";
    }
    
}
