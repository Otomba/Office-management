/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class CommentsController {

    public CommentsController() {
        pagingInfo = new PagingInfo();
        converter = new CommentsConverter();
    }
    private Comments comments = null;
    private List<Comments> commentsItems = null;
    private CommentsFacade jpaController = null;
    private CommentsConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public CommentsFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (CommentsFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "commentsJpa");
        }
        return jpaController;
    }

    public SelectItem[] getCommentsItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getCommentsItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Comments getComments() {
        if (comments == null) {
            comments = (Comments) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentComments", converter, null);
        }
        if (comments == null) {
            comments = new Comments();
        }
        return comments;
    }

    public String listSetup() {
        reset(true);
        return "comments_list";
    }

    public String createSetup() {
        reset(false);
        comments = new Comments();
        return "comments_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(comments);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Comments was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("comments_detail");
    }

    public String editSetup() {
        return scalarSetup("comments_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        comments = (Comments) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentComments", converter, null);
        if (comments == null) {
            String requestCommentsString = JsfUtil.getRequestParameter("jsfcrud.currentComments");
            JsfUtil.addErrorMessage("The comments with id " + requestCommentsString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String commentsString = converter.getAsString(FacesContext.getCurrentInstance(), null, comments);
        String currentCommentsString = JsfUtil.getRequestParameter("jsfcrud.currentComments");
        if (commentsString == null || commentsString.length() == 0 || !commentsString.equals(currentCommentsString)) {
            String outcome = editSetup();
            if ("comments_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit comments. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(comments);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Comments was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentComments");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Comments was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
     
        return listSetup();
    }

    public List<Comments> getCommentsItems() {
        if (commentsItems == null) {
            getPagingInfo();
            commentsItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return commentsItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "comments_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "comments_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        comments = null;
        commentsItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Comments newComments = new Comments();
        String newCommentsString = converter.getAsString(FacesContext.getCurrentInstance(), null, newComments);
        String commentsString = converter.getAsString(FacesContext.getCurrentInstance(), null, comments);
        if (!newCommentsString.equals(commentsString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
