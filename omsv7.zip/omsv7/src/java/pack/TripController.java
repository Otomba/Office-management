/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class TripController {

    public TripController() {
        pagingInfo = new PagingInfo();
        converter = new TripConverter();
    }
    private Trip trip = null;
    private List<Trip> tripItems = null;
    private TripFacade jpaController = null;
    private TripConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public TripFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (TripFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "tripJpa");
        }
        return jpaController;
    }

    public SelectItem[] getTripItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getTripItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Trip getTrip() {
        if (trip == null) {
            trip = (Trip) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTrip", converter, null);
        }
        if (trip == null) {
            trip = new Trip();
        }
        return trip;
    }

    public String listSetup() {
        reset(true);
        return "trip_list";
    }

    public String createSetup() {
        reset(false);
        trip = new Trip();
        return "trip_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(trip);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Trip was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("trip_detail");
    }

    public String editSetup() {
        return scalarSetup("trip_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        trip = (Trip) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTrip", converter, null);
        if (trip == null) {
            String requestTripString = JsfUtil.getRequestParameter("jsfcrud.currentTrip");
            JsfUtil.addErrorMessage("The trip with id " + requestTripString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String tripString = converter.getAsString(FacesContext.getCurrentInstance(), null, trip);
        String currentTripString = JsfUtil.getRequestParameter("jsfcrud.currentTrip");
        if (tripString == null || tripString.length() == 0 || !tripString.equals(currentTripString)) {
            String outcome = editSetup();
            if ("trip_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit trip. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(trip);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Trip was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentTrip");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Trip was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
     
        return listSetup();
    }

    public List<Trip> getTripItems() {
        if (tripItems == null) {
            getPagingInfo();
            tripItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return tripItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "trip_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "trip_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        trip = null;
        tripItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Trip newTrip = new Trip();
        String newTripString = converter.getAsString(FacesContext.getCurrentInstance(), null, newTrip);
        String tripString = converter.getAsString(FacesContext.getCurrentInstance(), null, trip);
        if (!newTripString.equals(tripString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
