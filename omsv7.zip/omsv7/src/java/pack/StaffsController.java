/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class StaffsController {

    public StaffsController() {
        pagingInfo = new PagingInfo();
        converter = new StaffsConverter();
    }
    private Staffs staffs = null;
    private List<Staffs> staffsItems = null;
    private StaffsFacade jpaController = null;
    private StaffsConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public StaffsFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (StaffsFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "staffsJpa");
        }
        return jpaController;
    }

    public SelectItem[] getStaffsItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getStaffsItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Staffs getStaffs() {
        if (staffs == null) {
            staffs = (Staffs) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentStaffs", converter, null);
        }
        if (staffs == null) {
            staffs = new Staffs();
        }
        return staffs;
    }

    public String listSetup() {
        reset(true);
        return "staffs_list";
    }

    public String createSetup() {
        reset(false);
        staffs = new Staffs();
        return "staffs_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(staffs);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Staffs was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("staffs_detail");
    }

    public String editSetup() {
        return scalarSetup("staffs_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        staffs = (Staffs) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentStaffs", converter, null);
        if (staffs == null) {
            String requestStaffsString = JsfUtil.getRequestParameter("jsfcrud.currentStaffs");
            JsfUtil.addErrorMessage("The staffs with id " + requestStaffsString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String staffsString = converter.getAsString(FacesContext.getCurrentInstance(), null, staffs);
        String currentStaffsString = JsfUtil.getRequestParameter("jsfcrud.currentStaffs");
        if (staffsString == null || staffsString.length() == 0 || !staffsString.equals(currentStaffsString)) {
            String outcome = editSetup();
            if ("staffs_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit staffs. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(staffs);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Staffs was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentStaffs");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Staffs was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
     
        return listSetup();
    }

    public List<Staffs> getStaffsItems() {
        if (staffsItems == null) {
            getPagingInfo();
            staffsItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return staffsItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "staffs_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "staffs_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        staffs = null;
        staffsItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Staffs newStaffs = new Staffs();
        String newStaffsString = converter.getAsString(FacesContext.getCurrentInstance(), null, newStaffs);
        String staffsString = converter.getAsString(FacesContext.getCurrentInstance(), null, staffs);
        if (!newStaffsString.equals(staffsString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
