/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class MilleageController {

    public MilleageController() {
        pagingInfo = new PagingInfo();
        converter = new MilleageConverter();
    }
    private Milleage milleage = null;
    private List<Milleage> milleageItems = null;
    private MilleageFacade jpaController = null;
    private MilleageConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public MilleageFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (MilleageFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "milleageJpa");
        }
        return jpaController;
    }

    public SelectItem[] getMilleageItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getMilleageItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Milleage getMilleage() {
        if (milleage == null) {
            milleage = (Milleage) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentMilleage", converter, null);
        }
        if (milleage == null) {
            milleage = new Milleage();
        }
        return milleage;
    }

    public String listSetup() {
        reset(true);
        return "milleage_list";
    }

    public String createSetup() {
        reset(false);
        milleage = new Milleage();
        return "milleage_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(milleage);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Milleage was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("milleage_detail");
    }

    public String editSetup() {
        return scalarSetup("milleage_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        milleage = (Milleage) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentMilleage", converter, null);
        if (milleage == null) {
            String requestMilleageString = JsfUtil.getRequestParameter("jsfcrud.currentMilleage");
            JsfUtil.addErrorMessage("The milleage with id " + requestMilleageString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String milleageString = converter.getAsString(FacesContext.getCurrentInstance(), null, milleage);
        String currentMilleageString = JsfUtil.getRequestParameter("jsfcrud.currentMilleage");
        if (milleageString == null || milleageString.length() == 0 || !milleageString.equals(currentMilleageString)) {
            String outcome = editSetup();
            if ("milleage_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit milleage. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(milleage);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Milleage was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentMilleage");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Milleage was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
      
        return listSetup();
    }

    public List<Milleage> getMilleageItems() {
        if (milleageItems == null) {
            getPagingInfo();
            milleageItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return milleageItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "milleage_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "milleage_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        milleage = null;
        milleageItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Milleage newMilleage = new Milleage();
        String newMilleageString = converter.getAsString(FacesContext.getCurrentInstance(), null, newMilleage);
        String milleageString = converter.getAsString(FacesContext.getCurrentInstance(), null, milleage);
        if (!newMilleageString.equals(milleageString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
