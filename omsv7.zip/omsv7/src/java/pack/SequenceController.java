/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class SequenceController {

    public SequenceController() {
        pagingInfo = new PagingInfo();
        converter = new SequenceConverter();
    }
    private Sequence sequence = null;
    private List<Sequence> sequenceItems = null;
    private SequenceFacade jpaController = null;
    private SequenceConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public SequenceFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (SequenceFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "sequenceJpa");
        }
        return jpaController;
    }

    public SelectItem[] getSequenceItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getSequenceItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Sequence getSequence() {
        if (sequence == null) {
            sequence = (Sequence) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentSequence", converter, null);
        }
        if (sequence == null) {
            sequence = new Sequence();
        }
        return sequence;
    }

    public String listSetup() {
        reset(true);
        return "sequence_list";
    }

    public String createSetup() {
        reset(false);
        sequence = new Sequence();
        return "sequence_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(sequence);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Sequence was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("sequence_detail");
    }

    public String editSetup() {
        return scalarSetup("sequence_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        sequence = (Sequence) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentSequence", converter, null);
        if (sequence == null) {
            String requestSequenceString = JsfUtil.getRequestParameter("jsfcrud.currentSequence");
            JsfUtil.addErrorMessage("The sequence with id " + requestSequenceString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String sequenceString = converter.getAsString(FacesContext.getCurrentInstance(), null, sequence);
        String currentSequenceString = JsfUtil.getRequestParameter("jsfcrud.currentSequence");
        if (sequenceString == null || sequenceString.length() == 0 || !sequenceString.equals(currentSequenceString)) {
            String outcome = editSetup();
            if ("sequence_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit sequence. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(sequence);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Sequence was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentSequence");
        String id = idAsString;
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Sequence was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
    
        return listSetup();
    }

    public List<Sequence> getSequenceItems() {
        if (sequenceItems == null) {
            getPagingInfo();
            sequenceItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return sequenceItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "sequence_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "sequence_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        sequence = null;
        sequenceItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Sequence newSequence = new Sequence();
        String newSequenceString = converter.getAsString(FacesContext.getCurrentInstance(), null, newSequence);
        String sequenceString = converter.getAsString(FacesContext.getCurrentInstance(), null, sequence);
        if (!newSequenceString.equals(sequenceString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
