/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "costsettings")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Costsettings.findAll", query = "SELECT c FROM Costsettings c")
    , @NamedQuery(name = "Costsettings.findById", query = "SELECT c FROM Costsettings c WHERE c.id = :id")
    , @NamedQuery(name = "Costsettings.findByPrice", query = "SELECT c FROM Costsettings c WHERE c.price = :price")
    , @NamedQuery(name = "Costsettings.findByTypeoftrip", query = "SELECT c FROM Costsettings c WHERE c.typeoftrip = :typeoftrip")})
public class Costsettings implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 100)
    @Column(name = "PRICE")
    private String price;
    @Size(max = 100)
    @Column(name = "TYPEOFTRIP")
    private String typeoftrip;
    @JoinColumn(name = "DIVERS_ID", referencedColumnName = "ID")
    @ManyToOne
    private Divers diversId;
    @OneToMany(mappedBy = "costsettingsId")
    private Collection<CostOfTransport> costOfTransportCollection;

    public Costsettings() {
    }

    public Costsettings(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTypeoftrip() {
        return typeoftrip;
    }

    public void setTypeoftrip(String typeoftrip) {
        this.typeoftrip = typeoftrip;
    }

    public Divers getDiversId() {
        return diversId;
    }

    public void setDiversId(Divers diversId) {
        this.diversId = diversId;
    }

    @XmlTransient
    public Collection<CostOfTransport> getCostOfTransportCollection() {
        return costOfTransportCollection;
    }

    public void setCostOfTransportCollection(Collection<CostOfTransport> costOfTransportCollection) {
        this.costOfTransportCollection = costOfTransportCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Costsettings)) {
            return false;
        }
        Costsettings other = (Costsettings) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pack.Costsettings[ id=" + id + " ]";
    }
    
}
