/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import javax.annotation.Resource;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;
import pack.util.JsfUtil;
import pack.util.PagingInfo;

/**
 *
 * @author user
 */
public class TitlesController {

    public TitlesController() {
        pagingInfo = new PagingInfo();
        converter = new TitlesConverter();
    }
    private Titles titles = null;
    private List<Titles> titlesItems = null;
    private TitlesFacade jpaController = null;
    private TitlesConverter converter = null;
    private PagingInfo pagingInfo = null;
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "omsv7PU")
    private EntityManagerFactory emf = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(getJpaController().count());
        }
        return pagingInfo;
    }

    public TitlesFacade getJpaController() {
        if (jpaController == null) {
            FacesContext facesContext = FacesContext.getCurrentInstance();
            jpaController = (TitlesFacade) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "titlesJpa");
        }
        return jpaController;
    }

    public SelectItem[] getTitlesItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), false);
    }

    public SelectItem[] getTitlesItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findAll(), true);
    }

    public Titles getTitles() {
        if (titles == null) {
            titles = (Titles) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTitles", converter, null);
        }
        if (titles == null) {
            titles = new Titles();
        }
        return titles;
    }

    public String listSetup() {
        reset(true);
        return "titles_list";
    }

    public String createSetup() {
        reset(false);
        titles = new Titles();
        return "titles_create";
    }

    public String create() {
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().create(titles);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Titles was successfully created.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("titles_detail");
    }

    public String editSetup() {
        return scalarSetup("titles_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        titles = (Titles) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentTitles", converter, null);
        if (titles == null) {
            String requestTitlesString = JsfUtil.getRequestParameter("jsfcrud.currentTitles");
            JsfUtil.addErrorMessage("The titles with id " + requestTitlesString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String titlesString = converter.getAsString(FacesContext.getCurrentInstance(), null, titles);
        String currentTitlesString = JsfUtil.getRequestParameter("jsfcrud.currentTitles");
        if (titlesString == null || titlesString.length() == 0 || !titlesString.equals(currentTitlesString)) {
            String outcome = editSetup();
            if ("titles_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit titles. Try again.");
            }
            return outcome;
        }
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().edit(titles);
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Titles was successfully updated.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String remove() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentTitles");
        Long id = new Long(idAsString);
        try {
            utx.begin();
        } catch (Exception ex) {
        }
        try {
            Exception transactionException = null;
            getJpaController().remove(getJpaController().find(id));
            try {
                utx.commit();
            } catch (javax.transaction.RollbackException ex) {
                transactionException = ex;
            } catch (Exception ex) {
            }
            if (transactionException == null) {
                JsfUtil.addSuccessMessage("Titles was successfully deleted.");
            } else {
                JsfUtil.ensureAddErrorMessage(transactionException, "A persistence error occurred.");
            }
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
            }
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
    
        return listSetup();
    }

    public List<Titles> getTitlesItems() {
        if (titlesItems == null) {
            getPagingInfo();
            titlesItems = getJpaController().findRange(new int[]{pagingInfo.getFirstItem(), pagingInfo.getFirstItem() + pagingInfo.getBatchSize()});
        }
        return titlesItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "titles_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "titles_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        titles = null;
        titlesItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Titles newTitles = new Titles();
        String newTitlesString = converter.getAsString(FacesContext.getCurrentInstance(), null, newTitles);
        String titlesString = converter.getAsString(FacesContext.getCurrentInstance(), null, titles);
        if (!newTitlesString.equals(titlesString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }
    
}
