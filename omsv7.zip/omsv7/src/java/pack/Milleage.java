/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "milleage")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Milleage.findAll", query = "SELECT m FROM Milleage m")
    , @NamedQuery(name = "Milleage.findById", query = "SELECT m FROM Milleage m WHERE m.id = :id")
    , @NamedQuery(name = "Milleage.findByKilometerEnding", query = "SELECT m FROM Milleage m WHERE m.kilometerEnding = :kilometerEnding")
    , @NamedQuery(name = "Milleage.findByKilometerStarting", query = "SELECT m FROM Milleage m WHERE m.kilometerStarting = :kilometerStarting")
    , @NamedQuery(name = "Milleage.findByKmDifference", query = "SELECT m FROM Milleage m WHERE m.kmDifference = :kmDifference")
    , @NamedQuery(name = "Milleage.findByTransportManagementId", query = "SELECT m FROM Milleage m WHERE m.transportManagementId = :transportManagementId")})
public class Milleage implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "KILOMETER_ENDING")
    private BigInteger kilometerEnding;
    @Column(name = "KILOMETER_STARTING")
    private BigInteger kilometerStarting;
    @Column(name = "KM_DIFFERENCE")
    private BigInteger kmDifference;
    @Column(name = "TRANSPORT_MANAGEMENT_ID")
    private BigInteger transportManagementId;
    @JoinColumn(name = "DIVERS_ID", referencedColumnName = "ID")
    @ManyToOne
    private Divers diversId;

    public Milleage() {
    }

    public Milleage(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigInteger getKilometerEnding() {
        return kilometerEnding;
    }

    public void setKilometerEnding(BigInteger kilometerEnding) {
        this.kilometerEnding = kilometerEnding;
    }

    public BigInteger getKilometerStarting() {
        return kilometerStarting;
    }

    public void setKilometerStarting(BigInteger kilometerStarting) {
        this.kilometerStarting = kilometerStarting;
    }

    public BigInteger getKmDifference() {
        return kmDifference;
    }

    public void setKmDifference(BigInteger kmDifference) {
        this.kmDifference = kmDifference;
    }

    public BigInteger getTransportManagementId() {
        return transportManagementId;
    }

    public void setTransportManagementId(BigInteger transportManagementId) {
        this.transportManagementId = transportManagementId;
    }

    public Divers getDiversId() {
        return diversId;
    }

    public void setDiversId(Divers diversId) {
        this.diversId = diversId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Milleage)) {
            return false;
        }
        Milleage other = (Milleage) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pack.Milleage[ id=" + id + " ]";
    }
    
}
